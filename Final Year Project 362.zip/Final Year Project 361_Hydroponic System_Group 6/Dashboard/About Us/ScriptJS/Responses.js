function Botresponses(input) {
    const responses = {
            "what is nft hydroponics?":
            "NFT Hydroponics refers to a hydroponic system utilizing the Nutrient Film Technique (NFT). In this method, a thin film of nutrient-rich water flows over plant roots, providing essential nutrients. NFT Hydroponics is known for its simplicity, efficiency, and scalability, allowing growers to cultivate plants with optimal nutrient absorption. This technique is favored for its ease of maintenance and adaptability to various plant types, making it a popular choice in modern, sustainable agriculture.",
            

            "What is hydroponics?":
            "Hydroponics is a soil-less method of growing plants, where nutrient-rich water delivers essential minerals directly to plant roots. Instead of traditional soil, hydroponics uses inert mediums like perlite or coconut coir to support plant roots. This method allows precise control over nutrient levels, pH, and environmental conditions, promoting faster plant growth and increased crop yields. Hydroponics is a sustainable and efficient agricultural practice that conserves water, reduces the need for pesticides, and enables year-round cultivation, making it an innovative approach to modern farming.",
            
            "What is the primary advantage of using NFT hydroponics over traditional soil-based farming?":
            "NFT hydroponics provides a more efficient nutrient delivery system + ensuring optimal nutrient uptake for plants, leading to faster growth and higher yields.",
       
            "How can I prevent nutrient deficiencies in my hydroponic system":
            "Regularly monitor nutrient levels and pH in your nutrient solution, adjusting as needed. Conduct routine water testing and maintain a balanced nutrient profile for healthy plant growth.",
        
            "What are the key components required to set up an NFT hydroponic system":
            "To set up an NFT hydroponic system, you'll need channels or tubes for nutrient flow, a nutrient reservoir, a pump, and a pH and EC monitoring system to ensure optimal conditions for plant growth.",
       
            "What are some common challenges faced in NFT hydroponics, and how can they be addressed":
            "Challenges may include nutrient imbalances, clogging in the channels, or pump failures. Regular maintenance, monitoring, and prompt problem-solving are key to overcoming these challenges.",
        
            "What types of crops are well-suited for NFT hydroponics?":
            "Leafy greens like lettuce and herbs. Tailoring the system to the specific needs of each crop is essential.",
       
            "How does pH affect nutrient uptake in hydroponics?":
            "pH levels impact the availability of nutrients to plants. Maintaining the correct pH range (typically between 5.5 and 6.5) ensures optimal nutrient absorption, preventing deficiencies or toxicities.",
        
            "How can we optimize resource use in our hydroponics project?":
            "Implement water recycling, use energy-efficient LED lighting, and explore sustainable nutrient sourcing.",
        
            "What challenges might we face in the project, and how do we plan to address them?":
            "Possible challenges include system maintenance and crop-specific needs. We will address them through thorough planning, regular checks, and prompt problem-solving.",
        
            "Could you elaborate on the advantages of using NFT hydroponics compared to traditional soil-based farming?":
            "Certainly! NFT hydroponics stands out for its ability to deliver nutrients more efficiently to plants. This method ensures optimal nutrient uptake, resulting in accelerated growth rates and ultimately higher yields than traditional soil-based approaches.",
       
            "What role do the alerts play in your system?":
            "The alerts in our NFT hydroponics system play a crucial role in monitoring and maintaining optimal conditions for plant growth. These alerts are designed to notify us of issues within the system, such as fluctuations in nutrient levels, pH imbalances, or potential equipment failures. By receiving timely alerts, we can take immediate action to address these issues.",
      
            "does NFT hydroponics help in addressing the charter of your project, food shortages?":
            "Yes, NFT hydroponics significantly contributes to addressing food shortages, a key charter of our project. This sustainable approach to farming helps in providing a consistent and increased supply of fresh produce, thereby contributing to alleviating food shortages and promoting food security.",
       
            "Who can be viewed as the stakeholders":
            [
                "1. The consumers",
                "2. The local community or communities",
                "3. Business owners whom operate in agriculture or seek to enter the agricultural sector",
                "4. The retailers",
                "5. The suppliers"
            ],
       
            "": "Sorry, I can't provide an answer to that."
    };

    return responses[input] || "Sorry, I can't provide an answer to that.";
}

