# Todo-List-App
Build a Todo List App in HTML CSS JavaScript | EASY BEGINNER TUTORIAL

This is the perfect project for beginner web developers who are looking to expand their knowledge of HTML CSS and JavaScript. This beginner JavaScript tutorial will teach you how to use local browser storage to create a fully functional todo list app!
